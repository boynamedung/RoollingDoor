﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Xml;

namespace giaodiencuacuon
{
    public partial class Form1 : Form
    {
        string receivedata = string.Empty; //biến nhận chuỗi
        string transmitdata = string.Empty; //biến gửi chuỗi
        int count1 = 0;
        int count2 = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            serialPort1.PortName = "Select COM Port ...";
            serialPort1.BaudRate = 9600; //baudrate 9600
            serialPort1.DataBits = 8; //data 8 
            serialPort1.Parity = Parity.None; //parity 0
            serialPort1.StopBits = StopBits.One; //stopbit 1
            string[] ports = SerialPort.GetPortNames(); //đọc tên COM
            foreach (string port in ports)
            {
                comboBox_comport.Items.Add(port); //thêm COM vào list dropdown
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e) // cấu hình button Disconnect
        {
            try //sử dụng cấu trúc try...catch để hoạt động và tránh hoạt động ngoại lệ
            {
                if (serialPort1.IsOpen) 
                {
                    serialPort1.Close(); 
                    textBox_statuscom.BackColor = Color.Red;
                    textBox_statuscom.Text = "Disconnected!";
                    MessageBox.Show("COM Port is disconnected.", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    comboBox_comport.Enabled = true;
                    comboBox_baudrate.Enabled = true;
                }
                else
                {
                    MessageBox.Show("COM Port have been disconnected. Please reconnect to use.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception)
                {
                MessageBox.Show("Disconnection appears error. Unable to disconnect.","Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
    }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) // cấu hình trạng thái connected hay disconnected
        {
            serialPort1.Close();
            textBox_statuscom.BackColor = Color.Red;
            textBox_statuscom.Text = "Disconnected!";
            serialPort1.PortName = comboBox_comport.Text;
        }

        private void button_connect_Click(object sender, EventArgs e) //cấu hình button connect
        {
            if (comboBox_comport.Text == "")
                MessageBox.Show("Select COM Port. ", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else if (comboBox_baudrate.Text == "")
                MessageBox.Show("Select baudrate for COM Port.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else
            {
                try
                {
                    if (serialPort1.IsOpen)
                    {
                        MessageBox.Show("COM Port is connected and ready for use.", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        serialPort1.Open();
                        MessageBox.Show(comboBox_comport.Text + " is connected", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        textBox_statuscom.BackColor = Color.Lime;
                        textBox_statuscom.Text = "Connected";
                        comboBox_comport.Enabled = false;
                        comboBox_baudrate.Enabled = false;
                        receivedata = string.Empty;
                        transmitdata = string.Empty;
                    }
                }
                catch (Exception)
                {
                    textBox_statuscom.BackColor = Color.Red;
                    textBox_statuscom.Text = " Disconnected!";
                    MessageBox.Show("COM Port is not found. Please check your COM or Cable.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
         public void Send_data(string Send_text) //gửi data qua serial
        {
            serialPort1.Write(Send_text);
        }       
        private void button_exit_Click(object sender, EventArgs e) //cấu hình button exit
        {
            DialogResult answer = MessageBox.Show("Do you want to exit the program?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                if (serialPort1.IsOpen)
                {
                    serialPort1.Close();
                }
                this.Close();
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e) //cấu hình khi click vào icon x để đóng 
        {
            if (serialPort1.IsOpen)
                serialPort1.Close();
        }

        private void button_open_Click(object sender, EventArgs e) //Cấu hình khi click vào nút OPEN
        {
            try
            {
                if (serialPort1.IsOpen)
                {
                    count1++;
                    if ((count1 % 2) != 0)
                    {
                        transmitdata = "1";
                        serialPort1.Write(transmitdata); //truyền data '1'
                        textBox_trangthaicuaht.Text = "Dang mo cua";
                    }
                    if ((count1 % 2) == 0)
                    {
                        transmitdata = "2";
                        serialPort1.Write(transmitdata);
                        count1 = 0;
                        textBox_trangthaicuaht.Text = "Da mo";
                    }
                }
                else //kiểm tra khi click vào object nhưng COM PORT bị ngắt kết nối
                {
                    MessageBox.Show("COM Port is disconnected.", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception) //kiểm tra khi click vào object nhưng không chọn COM PORT 
            {
                MessageBox.Show("COM Port is not found. Please check your COM or Cable.","Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button_close_Click(object sender, EventArgs e) //Cấu hình khi click vào nút CLOSE
        {
            try
            {
                if (serialPort1.IsOpen)
                {
                    count2++;
                    if ((count2 % 2) != 0)
                    {
                        transmitdata = "3";
                        serialPort1.Write(transmitdata); //truyền data '1'
                        textBox_trangthaicuaht.Text = "Dang dong cua";
                    }
                    if ((count2 % 2) == 0)
                    {
                        transmitdata = "4";
                        serialPort1.Write(transmitdata);
                        count2 = 0;
                        textBox_trangthaicuaht.Text = "Da dong";
                    }
                }
                else
                {
                    MessageBox.Show("COM Port is disconnected.", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("COM Port is not found. Please check your COM or Cable.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void serial_port_datareceive(object sender, SerialDataReceivedEventArgs e) //cấu hình hiển thị trạng thái đóng/mở
        {
            CheckForIllegalCrossThreadCalls = false; //biến kiểm tra xung đột
            String receivedata = serialPort1.ReadExisting(); //lưu data gửi từ arduino lưu vào receivedata
            if (receivedata == "A")
            {
                textBox_trangthaicuaht.Text = "Dang mo cua"; //hiển thị chuỗi nhận
            }
            if (receivedata == "B")
            {
                textBox_trangthaicuaht.Text = "Da mo"; //hiển thị chuỗi nhận
            }
            if (receivedata == "C")
            {
                textBox_trangthaicuaht.Text = "Dang dong cua"; //hiển thị chuỗi nhận
            }
            if (receivedata == "D")
            {
                textBox_trangthaicuaht.Text = "Da dong"; //hiển thị chuỗi nhận
            }
        }

        private void comboBox_baudrate_SelectedIndexChanged(object sender, EventArgs e)
        {
            serialPort1.Close();
            textBox_statuscom.BackColor = Color.Red;
            textBox_statuscom.Text = "Disconnected!";
            serialPort1.BaudRate = Convert.ToInt32(comboBox_baudrate.Text);
        }

        private void textBox_trangthaicuaht_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_sw2_Click(object sender, EventArgs e) //cấu hình nút SW2 khi click
        {
            try
            {
                if (serialPort1.IsOpen)
                {
                    transmitdata = "2";
                    serialPort1.Write(transmitdata); //truyền data '3'
                    count1 = 0;
                    textBox_trangthaicuaht.Text = "Da mo";
                }
                else
                {
                    MessageBox.Show("COM Port is disconnected.", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("COM Port is not found. Please check your COM or Cable.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button_sw1_Click(object sender, EventArgs e) //cấu hình nút SW2 khi click
        {
            try
            {
                if (serialPort1.IsOpen)
                {
                    transmitdata = "4";
                    serialPort1.Write(transmitdata); //truyền data '4'
                    count2 = 0;
                    textBox_trangthaicuaht.Text = "Da dong";
                }
                else
                {
                    MessageBox.Show("COM Port is disconnected.", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("COM Port is not found. Please check your COM or Cable.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void groupBox_caidatcom_Enter(object sender, EventArgs e)
        {

        }
        }
        }
        

