void ISR()
{
       PORTC.B4 = 1;
       PORTC.B5 = 0;
       INTCON.INT0IF = 0;
}
void main() {
     int count = 0;
     int count1 = 0;
     ADCON1 |= 0x0F;
     TRISB = 0xFF;
     TRISC = 0x00;
     PORTC = 0x00;
     INTCON.INTEDG0 = 1;
     INTCON.INTEDG1 = 1;
     INTCON.RBPU = 0;
     INTCON.INT0IF = 0;
     INTCON.INT1IF = 0;
     INTCON.INT0IE = 0;
     INTCON.INT1IE = 0;
     INTCON.GIE = 1;
     while(1)
     {

     }
}

