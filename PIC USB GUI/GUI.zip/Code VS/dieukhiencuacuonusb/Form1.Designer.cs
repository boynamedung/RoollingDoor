﻿namespace dieukhiencuacuonusb
{
    partial class Form_SampleCOM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox_DeviceInfor = new System.Windows.Forms.GroupBox();
            this.label_Product = new System.Windows.Forms.Label();
            this.label_Vendor = new System.Windows.Forms.Label();
            this.textBox_PN = new System.Windows.Forms.TextBox();
            this.textBox_VN = new System.Windows.Forms.TextBox();
            this.textBox_PID = new System.Windows.Forms.TextBox();
            this.textBox_VID = new System.Windows.Forms.TextBox();
            this.textBox_Status = new System.Windows.Forms.TextBox();
            this.label_VN = new System.Windows.Forms.Label();
            this.label_PN = new System.Windows.Forms.Label();
            this.label_PID = new System.Windows.Forms.Label();
            this.label_VID = new System.Windows.Forms.Label();
            this.label_DeviceStatus = new System.Windows.Forms.Label();
            this.label_infosv = new System.Windows.Forms.Label();
            this.button_exit = new System.Windows.Forms.Button();
            this.groupBox_hanhtrinhcua = new System.Windows.Forms.GroupBox();
            this.label_baomocua = new System.Windows.Forms.Label();
            this.label_baodongcua = new System.Windows.Forms.Label();
            this.button_sw1 = new System.Windows.Forms.Button();
            this.button_sw2 = new System.Windows.Forms.Button();
            this.label_tenphanmem = new System.Windows.Forms.Label();
            this.groupBox_trangthaicua = new System.Windows.Forms.GroupBox();
            this.textBox_trangthaicuaht = new System.Windows.Forms.TextBox();
            this.groupBox_dieukhiencua = new System.Windows.Forms.GroupBox();
            this.label_dongcua = new System.Windows.Forms.Label();
            this.label_mocua = new System.Windows.Forms.Label();
            this.button_close = new System.Windows.Forms.Button();
            this.button_open = new System.Windows.Forms.Button();
            this.usbHidPort1 = new UsbLibrary.UsbHidPort(this.components);
            this.toolStripStatusLabel1_InforDevice = new System.Windows.Forms.ToolStripStatusLabel();
            this.StatusStrip_InforDevice = new System.Windows.Forms.StatusStrip();
            this.groupBox_DeviceInfor.SuspendLayout();
            this.groupBox_hanhtrinhcua.SuspendLayout();
            this.groupBox_trangthaicua.SuspendLayout();
            this.groupBox_dieukhiencua.SuspendLayout();
            this.StatusStrip_InforDevice.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_DeviceInfor
            // 
            this.groupBox_DeviceInfor.Controls.Add(this.label_Product);
            this.groupBox_DeviceInfor.Controls.Add(this.label_Vendor);
            this.groupBox_DeviceInfor.Controls.Add(this.textBox_PN);
            this.groupBox_DeviceInfor.Controls.Add(this.textBox_VN);
            this.groupBox_DeviceInfor.Controls.Add(this.textBox_PID);
            this.groupBox_DeviceInfor.Controls.Add(this.textBox_VID);
            this.groupBox_DeviceInfor.Controls.Add(this.textBox_Status);
            this.groupBox_DeviceInfor.Controls.Add(this.label_VN);
            this.groupBox_DeviceInfor.Controls.Add(this.label_PN);
            this.groupBox_DeviceInfor.Controls.Add(this.label_PID);
            this.groupBox_DeviceInfor.Controls.Add(this.label_VID);
            this.groupBox_DeviceInfor.Controls.Add(this.label_DeviceStatus);
            this.groupBox_DeviceInfor.Location = new System.Drawing.Point(12, 46);
            this.groupBox_DeviceInfor.Name = "groupBox_DeviceInfor";
            this.groupBox_DeviceInfor.Size = new System.Drawing.Size(390, 220);
            this.groupBox_DeviceInfor.TabIndex = 6;
            this.groupBox_DeviceInfor.TabStop = false;
            this.groupBox_DeviceInfor.Text = "Device Information";
            this.groupBox_DeviceInfor.Enter += new System.EventHandler(this.groupBox_DeviceInfor_Enter);
            // 
            // label_Product
            // 
            this.label_Product.AutoSize = true;
            this.label_Product.Location = new System.Drawing.Point(241, 112);
            this.label_Product.Name = "label_Product";
            this.label_Product.Size = new System.Drawing.Size(122, 20);
            this.label_Product.TabIndex = 26;
            this.label_Product.Text = "for PIC18F4550";
            this.label_Product.Click += new System.EventHandler(this.label7_Click);
            // 
            // label_Vendor
            // 
            this.label_Vendor.AutoSize = true;
            this.label_Vendor.Location = new System.Drawing.Point(241, 74);
            this.label_Vendor.Name = "label_Vendor";
            this.label_Vendor.Size = new System.Drawing.Size(99, 20);
            this.label_Vendor.TabIndex = 25;
            this.label_Vendor.Text = "for Microchip";
            // 
            // textBox_PN
            // 
            this.textBox_PN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_PN.Location = new System.Drawing.Point(135, 182);
            this.textBox_PN.Name = "textBox_PN";
            this.textBox_PN.ReadOnly = true;
            this.textBox_PN.Size = new System.Drawing.Size(222, 26);
            this.textBox_PN.TabIndex = 24;
            this.textBox_PN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_VN
            // 
            this.textBox_VN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_VN.Location = new System.Drawing.Point(135, 147);
            this.textBox_VN.Name = "textBox_VN";
            this.textBox_VN.ReadOnly = true;
            this.textBox_VN.Size = new System.Drawing.Size(222, 26);
            this.textBox_VN.TabIndex = 23;
            this.textBox_VN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_PID
            // 
            this.textBox_PID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_PID.Location = new System.Drawing.Point(135, 109);
            this.textBox_PID.Name = "textBox_PID";
            this.textBox_PID.ReadOnly = true;
            this.textBox_PID.Size = new System.Drawing.Size(100, 26);
            this.textBox_PID.TabIndex = 22;
            this.textBox_PID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_VID
            // 
            this.textBox_VID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_VID.Location = new System.Drawing.Point(135, 71);
            this.textBox_VID.Name = "textBox_VID";
            this.textBox_VID.ReadOnly = true;
            this.textBox_VID.Size = new System.Drawing.Size(100, 26);
            this.textBox_VID.TabIndex = 21;
            this.textBox_VID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_VID.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBox_Status
            // 
            this.textBox_Status.BackColor = System.Drawing.Color.Red;
            this.textBox_Status.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Status.Location = new System.Drawing.Point(135, 33);
            this.textBox_Status.Name = "textBox_Status";
            this.textBox_Status.ReadOnly = true;
            this.textBox_Status.Size = new System.Drawing.Size(151, 26);
            this.textBox_Status.TabIndex = 20;
            this.textBox_Status.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label_VN
            // 
            this.label_VN.AutoSize = true;
            this.label_VN.Location = new System.Drawing.Point(6, 150);
            this.label_VN.Name = "label_VN";
            this.label_VN.Size = new System.Drawing.Size(107, 20);
            this.label_VN.TabIndex = 19;
            this.label_VN.Text = "Vendor Name";
            // 
            // label_PN
            // 
            this.label_PN.AutoSize = true;
            this.label_PN.Location = new System.Drawing.Point(6, 184);
            this.label_PN.Name = "label_PN";
            this.label_PN.Size = new System.Drawing.Size(110, 20);
            this.label_PN.TabIndex = 18;
            this.label_PN.Text = "Product Name";
            this.label_PN.Click += new System.EventHandler(this.label4_Click);
            // 
            // label_PID
            // 
            this.label_PID.AutoSize = true;
            this.label_PID.Location = new System.Drawing.Point(6, 112);
            this.label_PID.Name = "label_PID";
            this.label_PID.Size = new System.Drawing.Size(133, 20);
            this.label_PID.TabIndex = 17;
            this.label_PID.Text = "Product ID (HEX)";
            this.label_PID.Click += new System.EventHandler(this.label3_Click);
            // 
            // label_VID
            // 
            this.label_VID.AutoSize = true;
            this.label_VID.Location = new System.Drawing.Point(6, 74);
            this.label_VID.Name = "label_VID";
            this.label_VID.Size = new System.Drawing.Size(130, 20);
            this.label_VID.TabIndex = 16;
            this.label_VID.Text = "Vendor ID (HEX)";
            this.label_VID.Click += new System.EventHandler(this.label2_Click);
            // 
            // label_DeviceStatus
            // 
            this.label_DeviceStatus.AutoSize = true;
            this.label_DeviceStatus.Location = new System.Drawing.Point(11, 36);
            this.label_DeviceStatus.Name = "label_DeviceStatus";
            this.label_DeviceStatus.Size = new System.Drawing.Size(108, 20);
            this.label_DeviceStatus.TabIndex = 15;
            this.label_DeviceStatus.Text = "Device Status";
            this.label_DeviceStatus.Click += new System.EventHandler(this.label1_Click);
            // 
            // label_infosv
            // 
            this.label_infosv.AutoSize = true;
            this.label_infosv.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_infosv.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label_infosv.Location = new System.Drawing.Point(738, 234);
            this.label_infosv.Name = "label_infosv";
            this.label_infosv.Size = new System.Drawing.Size(261, 20);
            this.label_infosv.TabIndex = 17;
            this.label_infosv.Text = "Nguyễn Hùng Dũng - 18059441";
            // 
            // button_exit
            // 
            this.button_exit.Location = new System.Drawing.Point(797, 180);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(150, 36);
            this.button_exit.TabIndex = 16;
            this.button_exit.Text = "Exit Program";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // groupBox_hanhtrinhcua
            // 
            this.groupBox_hanhtrinhcua.Controls.Add(this.label_baomocua);
            this.groupBox_hanhtrinhcua.Controls.Add(this.label_baodongcua);
            this.groupBox_hanhtrinhcua.Controls.Add(this.button_sw1);
            this.groupBox_hanhtrinhcua.Controls.Add(this.button_sw2);
            this.groupBox_hanhtrinhcua.Location = new System.Drawing.Point(408, 155);
            this.groupBox_hanhtrinhcua.Name = "groupBox_hanhtrinhcua";
            this.groupBox_hanhtrinhcua.Size = new System.Drawing.Size(272, 111);
            this.groupBox_hanhtrinhcua.TabIndex = 13;
            this.groupBox_hanhtrinhcua.TabStop = false;
            this.groupBox_hanhtrinhcua.Text = "Hành trình đóng cửa";
            // 
            // label_baomocua
            // 
            this.label_baomocua.AutoSize = true;
            this.label_baomocua.Location = new System.Drawing.Point(55, 33);
            this.label_baomocua.Name = "label_baomocua";
            this.label_baomocua.Size = new System.Drawing.Size(99, 20);
            this.label_baomocua.TabIndex = 16;
            this.label_baomocua.Text = "Mở cửa xong";
            // 
            // label_baodongcua
            // 
            this.label_baodongcua.AutoSize = true;
            this.label_baodongcua.Location = new System.Drawing.Point(55, 71);
            this.label_baodongcua.Name = "label_baodongcua";
            this.label_baodongcua.Size = new System.Drawing.Size(116, 20);
            this.label_baodongcua.TabIndex = 15;
            this.label_baodongcua.Text = "Đóng cửa xong";
            // 
            // button_sw1
            // 
            this.button_sw1.Location = new System.Drawing.Point(191, 67);
            this.button_sw1.Name = "button_sw1";
            this.button_sw1.Size = new System.Drawing.Size(75, 36);
            this.button_sw1.TabIndex = 8;
            this.button_sw1.Text = "SW1";
            this.button_sw1.UseVisualStyleBackColor = true;
            this.button_sw1.Click += new System.EventHandler(this.button_sw1_Click);
            // 
            // button_sw2
            // 
            this.button_sw2.Location = new System.Drawing.Point(191, 25);
            this.button_sw2.Name = "button_sw2";
            this.button_sw2.Size = new System.Drawing.Size(75, 36);
            this.button_sw2.TabIndex = 7;
            this.button_sw2.Text = "SW2";
            this.button_sw2.UseVisualStyleBackColor = true;
            this.button_sw2.Click += new System.EventHandler(this.button_sw2_Click);
            // 
            // label_tenphanmem
            // 
            this.label_tenphanmem.AutoSize = true;
            this.label_tenphanmem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.label_tenphanmem.ForeColor = System.Drawing.Color.Navy;
            this.label_tenphanmem.Location = new System.Drawing.Point(338, 9);
            this.label_tenphanmem.Name = "label_tenphanmem";
            this.label_tenphanmem.Size = new System.Drawing.Size(395, 25);
            this.label_tenphanmem.TabIndex = 15;
            this.label_tenphanmem.Text = "ĐIỀU KHIỂN CỬA CUỐN - PIC18F4550";
            this.label_tenphanmem.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_tenphanmem.Click += new System.EventHandler(this.label_tenphanmem_Click);
            // 
            // groupBox_trangthaicua
            // 
            this.groupBox_trangthaicua.Controls.Add(this.textBox_trangthaicuaht);
            this.groupBox_trangthaicua.Location = new System.Drawing.Point(686, 46);
            this.groupBox_trangthaicua.Name = "groupBox_trangthaicua";
            this.groupBox_trangthaicua.Size = new System.Drawing.Size(350, 121);
            this.groupBox_trangthaicua.TabIndex = 14;
            this.groupBox_trangthaicua.TabStop = false;
            this.groupBox_trangthaicua.Text = "Trạng thái cửa";
            // 
            // textBox_trangthaicuaht
            // 
            this.textBox_trangthaicuaht.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_trangthaicuaht.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_trangthaicuaht.Location = new System.Drawing.Point(16, 50);
            this.textBox_trangthaicuaht.Name = "textBox_trangthaicuaht";
            this.textBox_trangthaicuaht.ReadOnly = true;
            this.textBox_trangthaicuaht.Size = new System.Drawing.Size(324, 26);
            this.textBox_trangthaicuaht.TabIndex = 14;
            this.textBox_trangthaicuaht.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox_dieukhiencua
            // 
            this.groupBox_dieukhiencua.Controls.Add(this.label_dongcua);
            this.groupBox_dieukhiencua.Controls.Add(this.label_mocua);
            this.groupBox_dieukhiencua.Controls.Add(this.button_close);
            this.groupBox_dieukhiencua.Controls.Add(this.button_open);
            this.groupBox_dieukhiencua.Location = new System.Drawing.Point(408, 46);
            this.groupBox_dieukhiencua.Name = "groupBox_dieukhiencua";
            this.groupBox_dieukhiencua.Size = new System.Drawing.Size(272, 103);
            this.groupBox_dieukhiencua.TabIndex = 12;
            this.groupBox_dieukhiencua.TabStop = false;
            this.groupBox_dieukhiencua.Text = "Điều khiển cửa cuốn";
            // 
            // label_dongcua
            // 
            this.label_dongcua.AutoSize = true;
            this.label_dongcua.Location = new System.Drawing.Point(55, 67);
            this.label_dongcua.Name = "label_dongcua";
            this.label_dongcua.Size = new System.Drawing.Size(78, 20);
            this.label_dongcua.TabIndex = 14;
            this.label_dongcua.Text = "Đóng cửa";
            // 
            // label_mocua
            // 
            this.label_mocua.AutoSize = true;
            this.label_mocua.Location = new System.Drawing.Point(55, 25);
            this.label_mocua.Name = "label_mocua";
            this.label_mocua.Size = new System.Drawing.Size(61, 20);
            this.label_mocua.TabIndex = 13;
            this.label_mocua.Text = "Mở cửa";
            // 
            // button_close
            // 
            this.button_close.Location = new System.Drawing.Point(191, 59);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(75, 36);
            this.button_close.TabIndex = 10;
            this.button_close.Text = "CLOSE";
            this.button_close.UseVisualStyleBackColor = true;
            this.button_close.Click += new System.EventHandler(this.button_close_Click);
            // 
            // button_open
            // 
            this.button_open.Location = new System.Drawing.Point(191, 17);
            this.button_open.Name = "button_open";
            this.button_open.Size = new System.Drawing.Size(75, 36);
            this.button_open.TabIndex = 9;
            this.button_open.Text = "OPEN";
            this.button_open.UseVisualStyleBackColor = true;
            this.button_open.Click += new System.EventHandler(this.button_open_Click);
            // 
            // usbHidPort1
            // 
            this.usbHidPort1.ProductId = 0;
            this.usbHidPort1.VendorId = 0;
            this.usbHidPort1.OnSpecifiedDeviceArrived += new System.EventHandler(this.usbHidPort_OnSpecifiedDeviceArrived);
            this.usbHidPort1.OnSpecifiedDeviceRemoved += new System.EventHandler(this.usbHidPort_OnSpecifiedDeviceRemoved);
            this.usbHidPort1.OnDeviceArrived += new System.EventHandler(this.usbHidPort_OnDataArrived);
            this.usbHidPort1.OnDeviceRemoved += new System.EventHandler(this.usbHidPort_OnRemoved);
            this.usbHidPort1.OnDataRecieved += new UsbLibrary.DataRecievedEventHandler(this.usbHidPort_OnDataRecieved);
            this.usbHidPort1.OnDataSend += new System.EventHandler(this.usbHidPort_OnDataSend);
            // 
            // toolStripStatusLabel1_InforDevice
            // 
            this.toolStripStatusLabel1_InforDevice.Name = "toolStripStatusLabel1_InforDevice";
            this.toolStripStatusLabel1_InforDevice.Size = new System.Drawing.Size(156, 25);
            this.toolStripStatusLabel1_InforDevice.Text = "USB Disconnected";
            // 
            // StatusStrip_InforDevice
            // 
            this.StatusStrip_InforDevice.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1_InforDevice});
            this.StatusStrip_InforDevice.Location = new System.Drawing.Point(0, 297);
            this.StatusStrip_InforDevice.Name = "StatusStrip_InforDevice";
            this.StatusStrip_InforDevice.Size = new System.Drawing.Size(1059, 30);
            this.StatusStrip_InforDevice.TabIndex = 18;
            this.StatusStrip_InforDevice.Text = "USB Disconnected";
            this.StatusStrip_InforDevice.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStripStatusLabel_InforDevice_ItemClicked);
            // 
            // Form_SampleCOM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1059, 327);
            this.Controls.Add(this.StatusStrip_InforDevice);
            this.Controls.Add(this.label_infosv);
            this.Controls.Add(this.groupBox_DeviceInfor);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.groupBox_trangthaicua);
            this.Controls.Add(this.groupBox_hanhtrinhcua);
            this.Controls.Add(this.label_tenphanmem);
            this.Controls.Add(this.groupBox_dieukhiencua);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form_SampleCOM";
            this.Text = "DIEU KHIEN CUA CUON USB HID";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox_DeviceInfor.ResumeLayout(false);
            this.groupBox_DeviceInfor.PerformLayout();
            this.groupBox_hanhtrinhcua.ResumeLayout(false);
            this.groupBox_hanhtrinhcua.PerformLayout();
            this.groupBox_trangthaicua.ResumeLayout(false);
            this.groupBox_trangthaicua.PerformLayout();
            this.groupBox_dieukhiencua.ResumeLayout(false);
            this.groupBox_dieukhiencua.PerformLayout();
            this.StatusStrip_InforDevice.ResumeLayout(false);
            this.StatusStrip_InforDevice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_DeviceInfor;
        private System.Windows.Forms.Label label_infosv;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.GroupBox groupBox_hanhtrinhcua;
        private System.Windows.Forms.Label label_baomocua;
        private System.Windows.Forms.Label label_baodongcua;
        private System.Windows.Forms.Button button_sw1;
        private System.Windows.Forms.Button button_sw2;
        private System.Windows.Forms.Label label_tenphanmem;
        private System.Windows.Forms.GroupBox groupBox_trangthaicua;
        private System.Windows.Forms.TextBox textBox_trangthaicuaht;
        private System.Windows.Forms.GroupBox groupBox_dieukhiencua;
        private System.Windows.Forms.Label label_dongcua;
        private System.Windows.Forms.Label label_mocua;
        private System.Windows.Forms.Button button_close;
        private System.Windows.Forms.Button button_open;
        private System.Windows.Forms.Label label_DeviceStatus;
        private System.Windows.Forms.Label label_VID;
        private System.Windows.Forms.Label label_PID;
        private System.Windows.Forms.Label label_PN;
        private System.Windows.Forms.Label label_Product;
        private System.Windows.Forms.Label label_Vendor;
        private System.Windows.Forms.TextBox textBox_PN;
        private System.Windows.Forms.TextBox textBox_VN;
        private System.Windows.Forms.TextBox textBox_PID;
        private System.Windows.Forms.TextBox textBox_VID;
        private System.Windows.Forms.TextBox textBox_Status;
        private System.Windows.Forms.Label label_VN;
        private UsbLibrary.UsbHidPort usbHidPort1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1_InforDevice;
        private System.Windows.Forms.StatusStrip StatusStrip_InforDevice;
    }
}

