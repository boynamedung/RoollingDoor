﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UsbLibrary;

namespace dieukhiencuacuonusb
{
    public partial class Form_SampleCOM : Form
    {
        int count = 0;
        int count1 = 0;
        byte[] readbuff = new byte[65];
        byte[] writebuff = new byte[65];
        public Form_SampleCOM()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label_tenphanmem_Click(object sender, EventArgs e)
        {

        }

        private void button_open_Click(object sender, EventArgs e)
        {
            count++;
            if ((count % 2) != 0)
            {
                writebuff[1] = 1;
                if (this.usbHidPort1.SpecifiedDevice != null)
                    this.usbHidPort1.SpecifiedDevice.SendData(writebuff);
                else
                {
                    MessageBox.Show("Device not found. Please reconnect USB device to use.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            if ((count % 2) == 0)
            {
                writebuff[1] = 2;
                count = 0;
                if (this.usbHidPort1.SpecifiedDevice != null)
                    this.usbHidPort1.SpecifiedDevice.SendData(writebuff);
                else
                {
                    MessageBox.Show("Device not found. Please reconnect USB device to use.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void button_close_Click(object sender, EventArgs e)
        {
            count1++;
            if ((count1 % 2) != 0)
            {
                writebuff[1] = 3;
                if (this.usbHidPort1.SpecifiedDevice != null)
                    this.usbHidPort1.SpecifiedDevice.SendData(writebuff);
                else
                {
                    MessageBox.Show("Device not found. Please reconnect USB device to use.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            if ((count1 % 2) == 0)
            {
                writebuff[1] = 4;
                count1 = 0;
                if (this.usbHidPort1.SpecifiedDevice != null)
                    this.usbHidPort1.SpecifiedDevice.SendData(writebuff);
                else
                {
                    MessageBox.Show("Device not found. Please reconnect USB device to use.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void button_sw2_Click(object sender, EventArgs e)
        {
            writebuff[1] = 2;
            count = 0;
            if (this.usbHidPort1.SpecifiedDevice != null)
                this.usbHidPort1.SpecifiedDevice.SendData(writebuff);
            else
            {
                MessageBox.Show("Device not found. Please reconnect USB device to use.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void toolStripStatusLabel_InforDevice_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.usbHidPort1.VendorId = 0x04d8;
            this.usbHidPort1.ProductId = 0x0001;
            this.usbHidPort1.CheckDevicePresent();

            if (this.usbHidPort1.SpecifiedDevice != null)
            {
                this.usbHidPort1.SpecifiedDevice.SendData(writebuff);
            }
            textBox_VID.Text = usbHidPort1.VendorId.ToString("x4");
            textBox_PID.Text = usbHidPort1.ProductId.ToString("x4");
        }

        private void groupBox_DeviceInfor_Enter(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            DialogResult answer = MessageBox.Show(" Do you want to exit the program ?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void button_sw1_Click(object sender, EventArgs e)
        {
            writebuff[1] = 4;
            count1 = 0;
            if (this.usbHidPort1.SpecifiedDevice != null)
                this.usbHidPort1.SpecifiedDevice.SendData(writebuff);
            else
            {
                MessageBox.Show("Device not found. Please reconnect USB device to use.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void usbHidPort_OnDataSend(object sender, EventArgs e)
        {
            toolStripStatusLabel1_InforDevice.Text = "Data sent";
        }

        private void usbHidPort_OnDataArrived(object sender, EventArgs e)
        {
            toolStripStatusLabel1_InforDevice.Text = "USB Connected";
        }

        private void usbHidPort_OnRemoved(object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                Invoke(new EventHandler(usbHidPort_OnRemoved), new object[] { sender, e });
            }
            else
            {
                toolStripStatusLabel1_InforDevice.Text = "USB Removed";
            }
        }

        private void usbHidPort_OnSpecifiedDeviceArrived(object sender, EventArgs e)
        {
            toolStripStatusLabel1_InforDevice.Text = "Device Detected";
            textBox_Status.Text = "Connected!";
            textBox_Status.BackColor = Color.Lime;
        }

        private void usbHidPort_OnDataRecieved(object sender, DataRecievedEventArgs args)
        {
            if (InvokeRequired)
            {
                try
                {
                    Invoke(new DataRecievedEventHandler(usbHidPort_OnDataRecieved), new object[] { sender, args });
                }
                catch
                { }
            }
            else
            {
                readbuff = args.data;
                toolStripStatusLabel1_InforDevice.Text = "New Received Data";
                if (readbuff[9] == 'A')
                {
                    textBox_trangthaicuaht.Text = "Cua dang mo";
                }
                else if (readbuff[9] == 'C')
                {
                    textBox_trangthaicuaht.Text = "Da mo";
                }
                else if (readbuff[9] == 'B')
                {
                    textBox_trangthaicuaht.Text = "Cua dang dong";
                }
                else if (readbuff[9] == 'D')
                {
                    textBox_trangthaicuaht.Text = "Da dong";
                }
            }
        }

        private void usbHidPort_OnSpecifiedDeviceRemoved(object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                Invoke(new EventHandler(usbHidPort_OnSpecifiedDeviceRemoved), new object[] { sender, e });
            }
            else
            {
                toolStripStatusLabel1_InforDevice.Text = "Device Disconnected";
                textBox_Status.Text = "Disconnected!";
                textBox_Status.BackColor = Color.Red;
            }
        }
        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            usbHidPort1.RegisterHandle(Handle);
        }
        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);
            usbHidPort1.ParseMessages(ref m);
        }
        private void textBox_trangthaicuaht_TextChanged(object sender, EventArgs e)
        {
        
        }
    }
}
