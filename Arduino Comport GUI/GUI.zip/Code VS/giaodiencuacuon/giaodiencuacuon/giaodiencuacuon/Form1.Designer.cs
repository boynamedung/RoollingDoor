﻿namespace giaodiencuacuon
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox_caidatcom = new System.Windows.Forms.GroupBox();
            this.comboBox_baudrate = new System.Windows.Forms.ComboBox();
            this.comboBox_comport = new System.Windows.Forms.ComboBox();
            this.textBox_statuscom = new System.Windows.Forms.TextBox();
            this.label_baudrate = new System.Windows.Forms.Label();
            this.label_comport = new System.Windows.Forms.Label();
            this.button_disconnect = new System.Windows.Forms.Button();
            this.button_connect = new System.Windows.Forms.Button();
            this.groupBox_dieukhiencua = new System.Windows.Forms.GroupBox();
            this.label_dongcua = new System.Windows.Forms.Label();
            this.label_mocua = new System.Windows.Forms.Label();
            this.button_close = new System.Windows.Forms.Button();
            this.button_open = new System.Windows.Forms.Button();
            this.groupBox_hanhtrinhcua = new System.Windows.Forms.GroupBox();
            this.label_baomocua = new System.Windows.Forms.Label();
            this.label_baodongcua = new System.Windows.Forms.Label();
            this.button_sw1 = new System.Windows.Forms.Button();
            this.button_sw2 = new System.Windows.Forms.Button();
            this.groupBox_trangthaicua = new System.Windows.Forms.GroupBox();
            this.textBox_trangthaicuaht = new System.Windows.Forms.TextBox();
            this.label_tenphanmem = new System.Windows.Forms.Label();
            this.button_exit = new System.Windows.Forms.Button();
            this.label_infosv = new System.Windows.Forms.Label();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.groupBox_caidatcom.SuspendLayout();
            this.groupBox_dieukhiencua.SuspendLayout();
            this.groupBox_hanhtrinhcua.SuspendLayout();
            this.groupBox_trangthaicua.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_caidatcom
            // 
            this.groupBox_caidatcom.Controls.Add(this.comboBox_baudrate);
            this.groupBox_caidatcom.Controls.Add(this.comboBox_comport);
            this.groupBox_caidatcom.Controls.Add(this.textBox_statuscom);
            this.groupBox_caidatcom.Controls.Add(this.label_baudrate);
            this.groupBox_caidatcom.Controls.Add(this.label_comport);
            this.groupBox_caidatcom.Controls.Add(this.button_disconnect);
            this.groupBox_caidatcom.Controls.Add(this.button_connect);
            this.groupBox_caidatcom.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_caidatcom.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox_caidatcom.Location = new System.Drawing.Point(12, 37);
            this.groupBox_caidatcom.Name = "groupBox_caidatcom";
            this.groupBox_caidatcom.Size = new System.Drawing.Size(272, 220);
            this.groupBox_caidatcom.TabIndex = 0;
            this.groupBox_caidatcom.TabStop = false;
            this.groupBox_caidatcom.Text = "Cài đặt cổng COM";
            this.groupBox_caidatcom.Enter += new System.EventHandler(this.groupBox_caidatcom_Enter);
            // 
            // comboBox_baudrate
            // 
            this.comboBox_baudrate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_baudrate.FormattingEnabled = true;
            this.comboBox_baudrate.Items.AddRange(new object[] {
            "1200",
            "2400",
            "4800",
            "9600",
            "19200",
            "38400"});
            this.comboBox_baudrate.Location = new System.Drawing.Point(134, 80);
            this.comboBox_baudrate.Name = "comboBox_baudrate";
            this.comboBox_baudrate.Size = new System.Drawing.Size(121, 28);
            this.comboBox_baudrate.TabIndex = 13;
            this.comboBox_baudrate.SelectedIndexChanged += new System.EventHandler(this.comboBox_baudrate_SelectedIndexChanged);
            // 
            // comboBox_comport
            // 
            this.comboBox_comport.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_comport.FormattingEnabled = true;
            this.comboBox_comport.Location = new System.Drawing.Point(134, 38);
            this.comboBox_comport.Name = "comboBox_comport";
            this.comboBox_comport.Size = new System.Drawing.Size(121, 28);
            this.comboBox_comport.TabIndex = 11;
            this.comboBox_comport.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // textBox_statuscom
            // 
            this.textBox_statuscom.BackColor = System.Drawing.Color.Red;
            this.textBox_statuscom.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_statuscom.Location = new System.Drawing.Point(57, 127);
            this.textBox_statuscom.Name = "textBox_statuscom";
            this.textBox_statuscom.ReadOnly = true;
            this.textBox_statuscom.Size = new System.Drawing.Size(166, 26);
            this.textBox_statuscom.TabIndex = 1;
            this.textBox_statuscom.Text = "Disconnected!";
            this.textBox_statuscom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_statuscom.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label_baudrate
            // 
            this.label_baudrate.AutoSize = true;
            this.label_baudrate.Location = new System.Drawing.Point(14, 83);
            this.label_baudrate.Name = "label_baudrate";
            this.label_baudrate.Size = new System.Drawing.Size(86, 20);
            this.label_baudrate.TabIndex = 12;
            this.label_baudrate.Text = "Baud Rate";
            // 
            // label_comport
            // 
            this.label_comport.AutoSize = true;
            this.label_comport.Location = new System.Drawing.Point(14, 41);
            this.label_comport.Name = "label_comport";
            this.label_comport.Size = new System.Drawing.Size(92, 20);
            this.label_comport.TabIndex = 11;
            this.label_comport.Text = "COM PORT";
            // 
            // button_disconnect
            // 
            this.button_disconnect.Location = new System.Drawing.Point(148, 172);
            this.button_disconnect.Name = "button_disconnect";
            this.button_disconnect.Size = new System.Drawing.Size(107, 36);
            this.button_disconnect.TabIndex = 5;
            this.button_disconnect.Text = "Disconncet";
            this.button_disconnect.UseVisualStyleBackColor = true;
            this.button_disconnect.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_connect
            // 
            this.button_connect.Location = new System.Drawing.Point(18, 172);
            this.button_connect.Name = "button_connect";
            this.button_connect.Size = new System.Drawing.Size(93, 36);
            this.button_connect.TabIndex = 6;
            this.button_connect.Text = "Connect";
            this.button_connect.UseVisualStyleBackColor = true;
            this.button_connect.Click += new System.EventHandler(this.button_connect_Click);
            // 
            // groupBox_dieukhiencua
            // 
            this.groupBox_dieukhiencua.Controls.Add(this.label_dongcua);
            this.groupBox_dieukhiencua.Controls.Add(this.label_mocua);
            this.groupBox_dieukhiencua.Controls.Add(this.button_close);
            this.groupBox_dieukhiencua.Controls.Add(this.button_open);
            this.groupBox_dieukhiencua.Location = new System.Drawing.Point(290, 37);
            this.groupBox_dieukhiencua.Name = "groupBox_dieukhiencua";
            this.groupBox_dieukhiencua.Size = new System.Drawing.Size(272, 103);
            this.groupBox_dieukhiencua.TabIndex = 1;
            this.groupBox_dieukhiencua.TabStop = false;
            this.groupBox_dieukhiencua.Text = "Điều khiển cửa cuốn";
            // 
            // label_dongcua
            // 
            this.label_dongcua.AutoSize = true;
            this.label_dongcua.Location = new System.Drawing.Point(55, 67);
            this.label_dongcua.Name = "label_dongcua";
            this.label_dongcua.Size = new System.Drawing.Size(78, 20);
            this.label_dongcua.TabIndex = 14;
            this.label_dongcua.Text = "Đóng cửa";
            // 
            // label_mocua
            // 
            this.label_mocua.AutoSize = true;
            this.label_mocua.Location = new System.Drawing.Point(55, 25);
            this.label_mocua.Name = "label_mocua";
            this.label_mocua.Size = new System.Drawing.Size(61, 20);
            this.label_mocua.TabIndex = 13;
            this.label_mocua.Text = "Mở cửa";
            // 
            // button_close
            // 
            this.button_close.Location = new System.Drawing.Point(191, 59);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(75, 36);
            this.button_close.TabIndex = 10;
            this.button_close.Text = "CLOSE";
            this.button_close.UseVisualStyleBackColor = true;
            this.button_close.Click += new System.EventHandler(this.button_close_Click);
            // 
            // button_open
            // 
            this.button_open.Location = new System.Drawing.Point(191, 17);
            this.button_open.Name = "button_open";
            this.button_open.Size = new System.Drawing.Size(75, 36);
            this.button_open.TabIndex = 9;
            this.button_open.Text = "OPEN";
            this.button_open.UseVisualStyleBackColor = true;
            this.button_open.Click += new System.EventHandler(this.button_open_Click);
            // 
            // groupBox_hanhtrinhcua
            // 
            this.groupBox_hanhtrinhcua.Controls.Add(this.label_baomocua);
            this.groupBox_hanhtrinhcua.Controls.Add(this.label_baodongcua);
            this.groupBox_hanhtrinhcua.Controls.Add(this.button_sw1);
            this.groupBox_hanhtrinhcua.Controls.Add(this.button_sw2);
            this.groupBox_hanhtrinhcua.Location = new System.Drawing.Point(290, 146);
            this.groupBox_hanhtrinhcua.Name = "groupBox_hanhtrinhcua";
            this.groupBox_hanhtrinhcua.Size = new System.Drawing.Size(272, 111);
            this.groupBox_hanhtrinhcua.TabIndex = 2;
            this.groupBox_hanhtrinhcua.TabStop = false;
            this.groupBox_hanhtrinhcua.Text = "Hành trình đóng cửa";
            // 
            // label_baomocua
            // 
            this.label_baomocua.AutoSize = true;
            this.label_baomocua.Location = new System.Drawing.Point(55, 33);
            this.label_baomocua.Name = "label_baomocua";
            this.label_baomocua.Size = new System.Drawing.Size(99, 20);
            this.label_baomocua.TabIndex = 16;
            this.label_baomocua.Text = "Mở cửa xong";
            // 
            // label_baodongcua
            // 
            this.label_baodongcua.AutoSize = true;
            this.label_baodongcua.Location = new System.Drawing.Point(55, 71);
            this.label_baodongcua.Name = "label_baodongcua";
            this.label_baodongcua.Size = new System.Drawing.Size(116, 20);
            this.label_baodongcua.TabIndex = 15;
            this.label_baodongcua.Text = "Đóng cửa xong";
            // 
            // button_sw1
            // 
            this.button_sw1.Location = new System.Drawing.Point(191, 67);
            this.button_sw1.Name = "button_sw1";
            this.button_sw1.Size = new System.Drawing.Size(75, 36);
            this.button_sw1.TabIndex = 8;
            this.button_sw1.Text = "SW1";
            this.button_sw1.UseVisualStyleBackColor = true;
            this.button_sw1.Click += new System.EventHandler(this.button_sw1_Click);
            // 
            // button_sw2
            // 
            this.button_sw2.Location = new System.Drawing.Point(191, 25);
            this.button_sw2.Name = "button_sw2";
            this.button_sw2.Size = new System.Drawing.Size(75, 36);
            this.button_sw2.TabIndex = 7;
            this.button_sw2.Text = "SW2";
            this.button_sw2.UseVisualStyleBackColor = true;
            this.button_sw2.Click += new System.EventHandler(this.button_sw2_Click);
            // 
            // groupBox_trangthaicua
            // 
            this.groupBox_trangthaicua.Controls.Add(this.textBox_trangthaicuaht);
            this.groupBox_trangthaicua.Location = new System.Drawing.Point(568, 37);
            this.groupBox_trangthaicua.Name = "groupBox_trangthaicua";
            this.groupBox_trangthaicua.Size = new System.Drawing.Size(350, 121);
            this.groupBox_trangthaicua.TabIndex = 3;
            this.groupBox_trangthaicua.TabStop = false;
            this.groupBox_trangthaicua.Text = "Trạng thái cửa";
            // 
            // textBox_trangthaicuaht
            // 
            this.textBox_trangthaicuaht.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_trangthaicuaht.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_trangthaicuaht.Location = new System.Drawing.Point(16, 50);
            this.textBox_trangthaicuaht.Name = "textBox_trangthaicuaht";
            this.textBox_trangthaicuaht.ReadOnly = true;
            this.textBox_trangthaicuaht.Size = new System.Drawing.Size(324, 26);
            this.textBox_trangthaicuaht.TabIndex = 14;
            this.textBox_trangthaicuaht.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_trangthaicuaht.TextChanged += new System.EventHandler(this.textBox_trangthaicuaht_TextChanged);
            // 
            // label_tenphanmem
            // 
            this.label_tenphanmem.AutoSize = true;
            this.label_tenphanmem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.label_tenphanmem.ForeColor = System.Drawing.Color.Navy;
            this.label_tenphanmem.Location = new System.Drawing.Point(220, 9);
            this.label_tenphanmem.Name = "label_tenphanmem";
            this.label_tenphanmem.Size = new System.Drawing.Size(494, 25);
            this.label_tenphanmem.TabIndex = 4;
            this.label_tenphanmem.Text = "ĐIỀU KHIỂN CỬA CUỐN - ARDUINO MEGA 2560";
            this.label_tenphanmem.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_tenphanmem.Click += new System.EventHandler(this.label1_Click);
            // 
            // button_exit
            // 
            this.button_exit.Location = new System.Drawing.Point(679, 171);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(150, 36);
            this.button_exit.TabIndex = 9;
            this.button_exit.Text = "Exit Program";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // label_infosv
            // 
            this.label_infosv.AutoSize = true;
            this.label_infosv.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_infosv.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label_infosv.Location = new System.Drawing.Point(620, 225);
            this.label_infosv.Name = "label_infosv";
            this.label_infosv.Size = new System.Drawing.Size(261, 20);
            this.label_infosv.TabIndex = 10;
            this.label_infosv.Text = "Nguyễn Hùng Dũng - 18059441";
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serial_port_datareceive);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(925, 263);
            this.Controls.Add(this.label_infosv);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.groupBox_hanhtrinhcua);
            this.Controls.Add(this.label_tenphanmem);
            this.Controls.Add(this.groupBox_trangthaicua);
            this.Controls.Add(this.groupBox_dieukhiencua);
            this.Controls.Add(this.groupBox_caidatcom);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GIAO TIẾP CỔNG COM - ĐIỀU KHIỂN CỬA CUỐN";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox_caidatcom.ResumeLayout(false);
            this.groupBox_caidatcom.PerformLayout();
            this.groupBox_dieukhiencua.ResumeLayout(false);
            this.groupBox_dieukhiencua.PerformLayout();
            this.groupBox_hanhtrinhcua.ResumeLayout(false);
            this.groupBox_hanhtrinhcua.PerformLayout();
            this.groupBox_trangthaicua.ResumeLayout(false);
            this.groupBox_trangthaicua.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_caidatcom;
        private System.Windows.Forms.GroupBox groupBox_dieukhiencua;
        private System.Windows.Forms.Label label_tenphanmem;
        private System.Windows.Forms.GroupBox groupBox_hanhtrinhcua;
        private System.Windows.Forms.GroupBox groupBox_trangthaicua;
        private System.Windows.Forms.Button button_disconnect;
        private System.Windows.Forms.ComboBox comboBox_baudrate;
        private System.Windows.Forms.ComboBox comboBox_comport;
        private System.Windows.Forms.TextBox textBox_statuscom;
        private System.Windows.Forms.Label label_baudrate;
        private System.Windows.Forms.Label label_comport;
        private System.Windows.Forms.Button button_connect;
        private System.Windows.Forms.Label label_dongcua;
        private System.Windows.Forms.Label label_mocua;
        private System.Windows.Forms.Button button_close;
        private System.Windows.Forms.Button button_open;
        private System.Windows.Forms.Label label_baomocua;
        private System.Windows.Forms.Label label_baodongcua;
        private System.Windows.Forms.Button button_sw1;
        private System.Windows.Forms.Button button_sw2;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.Label label_infosv;
        private System.Windows.Forms.TextBox textBox_trangthaicuaht;
        private System.IO.Ports.SerialPort serialPort1;
    }
}

